#! /bin/sh
python dataIngestion.py