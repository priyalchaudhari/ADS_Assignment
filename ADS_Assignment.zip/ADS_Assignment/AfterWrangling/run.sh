#! /bin/sh
python wrangle.py